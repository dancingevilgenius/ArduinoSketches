var searchData=
[
  ['useextendedframelength',['useExtendedFrameLength',['../classDW1000Class.html#ad34e8cd07429db763b9e51e496c4ec1a',1,'DW1000Class']]],
  ['userangefilter',['useRangeFilter',['../classDW1000RangingClass.html#af5de16473d8f33165bcf097428535121',1,'DW1000RangingClass']]],
  ['usesmartpower',['useSmartPower',['../classDW1000Class.html#a553b32a50b0be672319c0c6a04c3b9cf',1,'DW1000Class']]]
];
